


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySQLTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException  {
		
		
			
			Class.forName("com.mysql.jdbc.Driver");
		    Connection con = DriverManager.getConnection("jdbc:mysql://mysql-rfam-public.ebi.ac.uk:4497/Rfam","rfamro","");
		    
		    PreparedStatement ps = con.prepareStatement("select * from Rfam.pseudoknot");
		    
		    ResultSet rs = ps.executeQuery();
		    
		    while(rs.next()) {
		    	
		    	System.out.println(rs.getString("pseudoknot_id")+" "+rs.getString("count"));
		    }
		
	
	}

}