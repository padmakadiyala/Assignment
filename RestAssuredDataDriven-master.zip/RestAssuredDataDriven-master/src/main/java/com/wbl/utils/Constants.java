package com.wbl.utils;

public interface Constants {
String Resources_path=System.getProperty("user.dir")+"/resources/";
}
